import "./styles.css";
import "./ui/app.ts";
// OpenClaw integration boot (mountOpenClawChat, attachOpenClawWebSocket)
import "./ui/openclaw_boot";
